<?php
session_start();
include("connection.php");
if (!isset($_SESSION['akun_username'])) {
    header("location:login.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <style>

    </style>
</head>

<body>
<nav class="navbar bg-dark">
<nav class="navbar navbar-expand-lg bg-body-tertiary">
<div class="navbar-nav">

<a class="nav-link" aria-current="page" href="utama.php">Home</a>

<?php if (in_array("admin", $_SESSION['akun_akses'])) { ?>
<a class="nav-link" href="admin.php">Halaman Admin</a>
<?php } ?>

<?php if (in_array("guru", $_SESSION['akun_akses'])) { ?>
<a class="nav-link" href="guru.php">Halaman Guru</a>
<?php } ?>

<?php if (in_array("siswa", $_SESSION['akun_akses'])) { ?>
<a class="nav-link" href="siswa.php">Halaman Siswa</a>
<?php } ?>

<a href="logout.php"><button class="btn btn-outline-danger" type="submit">Logout</button></a>

</div>
</nav>
</nav>
<br><br>

</body>
</html>