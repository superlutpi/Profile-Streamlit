<?php
$host       = "localhost";
$user       = "root";
$pass       = "";
$db         = "lutpi";

$koneksi    = mysqli_connect($host, $user, $pass, $db);
if (!$koneksi) { //cek koneksi
    die("Tidak bisa terkoneksi ke database");
}
$pertanyaan     = "";
$jawaban_a      = "";
$jawaban_b      = "";
$jawaban_c      = "";
$jawaban_d      = "";
$jawabanbenar   = "";
$nomor          = "";
$sukses         = "";
$error          = "";

if (isset($_GET['op'])) {
    $op = $_GET['op'];
} else {
    $op = "";
}
if($op == 'delete'){
    $nomor         = $_GET['nomor'];
    $sql1       = "delete from soal where nomor = '$nomor'";
    $q1         = mysqli_query($koneksi,$sql1);
    if($q1){
        $sukses = "Berhasil hapus data";
    }else{
        $error  = "Gagal melakukan delete data";
    }
}
if ($op == 'edit') {
    $nomor          = $_GET['nomor'];
    $sql1           = "select * from soal where nomor = '$nomor'";
    $q1             = mysqli_query($koneksi, $sql1);
    $r1             = mysqli_fetch_array($q1);
    $pertanyaan     = $r1['pertanyaan'];
    $jawaban_a      = $r1['jawaban_a'];
    $jawaban_b      = $r1['jawaban_b'];
    $jawaban_c      = $r1['jawaban_c'];
    $jawaban_d      = $r1['jawaban_d'];
    $jawabanbenar   = $r1['jawabanbenar'];

    if ($nomor == '') {
        $error = "Data tidak ditemukan";
    }
}
if (isset($_POST['simpan'])) { //untuk create
    $pertanyaan       = $_POST['pertanyaan'];
    $jawaban_a        = $_POST['jawaban_a'];
    $jawaban_b        = $_POST['jawaban_b'];
    $jawaban_c        = $_POST['jawaban_c'];
    $jawaban_d        = $_POST['jawaban_d'];
    $jawabanbenar     = $_POST['jawabanbenar'];

    if ($pertanyaan && $jawaban_a && $jawaban_b && $jawaban_c && $jawaban_d && $jawabanbenar) {
        if ($op == 'edit') { //untuk update
            $sql1       = "update soal set pertanyaan='$pertanyaan', jawaban_a = '$jawaban_a', jawaban_b='$jawaban_b', jawaban_c='$jawaban_c', jawaban_d='$jawaban_d', jawabanbenar='$jawabanbenar' where nomor = '$nomor'";
            $q1         = mysqli_query($koneksi, $sql1);
            if ($q1) {
                $sukses = "Data berhasil diupdate";
            } else {
                $error  = "Data gagal diupdate";
            }
        } 
        else { //untuk edit
            $sql1   = "insert into soal(nomor,pertanyaan,jawaban_a,jawaban_b,jawaban_c,jawaban_d,jawabanbenar) values ('$nomor','$pertanyaan','$jawaban_a','$jawaban_b','$jawaban_c','$jawaban_d','$jawabanbenar')";
            $q1     = mysqli_query($koneksi, $sql1);
            if ($q1) {
                $sukses     = "Berhasil memasukkan data baru";
            } else {
                $error      = "Gagal memasukkan data";
            }
        }
    } 
    else {
        $error = "Silakan masukkan semua data";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pembuatan Soal Pilihan Ganda</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <style>
        body {
            background-color: #5C8984;
        }
        .mx-auto {
            width: 60%;
        }

        .card {
            margin-top: 10px;
        }

        .hai{
            margin-top: 20px;
        }

        .helo{
            margin-right: 10px;
        }
    </style>
</head>

<body>
    <div class="mx-auto">
        <!-- untuk memasukkan data -->
        <div class="card">
            <div class="card-header">
                Buat soal pilihan ganda
            </div>
            <div class="card-body">
                <?php
                if ($error) {
                ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo $error ?>
                    </div>
                <?php
                    header("refresh:3;url=soal.php");//3 : detik
                }
                ?>
                <?php
                if ($sukses) {
                ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo $sukses ?>
                    </div>
                <?php
                    header("refresh:5;url=soal.php");
                }
                ?>
                <form action="" method="POST">
                    <div class="mb-3 row">
                        <label for="pertanyaan" class="col-sm-2 col-form-label">Pertanyaan</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="pertanyaan" name="pertanyaan" value="<?php echo $pertanyaan ?>">
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="jawaban_a" class="col-sm-2 col-form-label">A</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="jawaban_a" name="jawaban_a" value="<?php echo $jawaban_a ?>">
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="jawaban_b" class="col-sm-2 col-form-label">B</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="jawaban_b" name="jawaban_b" value="<?php echo $jawaban_b ?>">
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="jawaban_c" class="col-sm-2 col-form-label">C</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="jawaban_c" name="jawaban_c" value="<?php echo $jawaban_c ?>">
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="jawaban_d" class="col-sm-2 col-form-label">D</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="jawaban_d" name="jawaban_d" value="<?php echo $jawaban_d ?>">
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="jawabanbenar" class="col-sm-2 col-form-label">Jawaban Benar</label>
                        <div class="col-sm-10">
                            <select class="form-control" name="jawabanbenar" id="jawabanbenar">
                                <option value="">-</option>
                                <option value="A" <?php if ($jawabanbenar == "A") echo "selected" ?>>A</option>
                                <option value="B" <?php if ($jawabanbenar == "B") echo "selected" ?>>B</option>
                                <option value="C" <?php if ($jawabanbenar == "C") echo "selected" ?>>C</option>
                                <option value="D" <?php if ($jawabanbenar == "D") echo "selected" ?>>D</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-12">
                        <input type="submit" name="simpan" value="Simpan Data" class="btn btn-primary" />
                    </div>
                </form>
            </div>
        </div>

        <!-- untuk mengeluarkan data -->
        <div class="card">
            <div class="card-header text-white bg-secondary">
                Hasil soal yang dibuat
            </div>
            <div class="card-body">
                <table class="table">
                    <tbody>
                        <?php
                        $sql2   = "select * from soal order by nomor desc";
                        $q2     = mysqli_query($koneksi, $sql2);
                        while ($r2 = mysqli_fetch_array($q2)) {
                            $nomor          = $r2['nomor'];
                            $pertanyaan     = $r2['pertanyaan'];
                            $jawaban_a      = $r2['jawaban_a'];
                            $jawaban_b      = $r2['jawaban_b'];
                            $jawaban_c      = $r2['jawaban_c'];
                            $jawaban_d      = $r2['jawaban_d'];
                            $jawabanbenar   = $r2['jawabanbenar'];

                        ?>
                            <ul>
                                <li><b><?php echo $pertanyaan ?></b></li>
                                <li type="none">A.<?php echo $jawaban_b ?></li>
                                <li type="none">B.<?php echo $jawaban_a ?></li>
                                <li type="none">C.<?php echo $jawaban_c ?></li>
                                <li type="none">D.<?php echo $jawaban_d ?></li>
                                <li type="none"><b>Jawaban Benar : <?php echo $jawabanbenar ?></b></li>
                                <li type="none">
                                    <a href="soal.php?op=edit&nomor=<?php echo $nomor ?>"><button type="button" class="btn btn-warning">Edit</button></a>
                                    <a href="soal.php?op=delete&nomor=<?php echo $nomor?>" onclick="return confirm('Yakin mau delete data?')"><button type="button" class="btn btn-danger">Delete</button></a>            
                                </li>
                            </ul>
                            <br>
                        <?php
                        }
                        ?>
                    <hr>
                    </tbody>
                    <div class="col-12">
                        <a href="guru.php"><input type="button" name="kembali" value="Kembali" class="btn btn-warning"></a>
                    </div>
                </table>
            </div>
        </div>
    </div>
</body>


</html>

<br><br>
<?php
include("footer.php");
?>