<?php
include("header.php");

if (!in_array("siswa", $_SESSION['akun_akses'])) {
    echo "Kamu tidak punya akses";
    include("footer.php");
    exit();
}
?>

<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Siswa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <style>
        body {
            background-color: beige;
        }
        .mx-auto {
            width: 70%;
        }

        .card {
            margin-top: 10px;
        }

        .hai{
            margin-top: 20px;
        }

        .helo{
            margin-right: 10px;
        }
    </style>
</head>

<body background="work3.jpg">
<center><h1><b>Halaman Siswa</b></h1></center>
<center>Selamat datang di halaman siswa</center>
<br>

<div>
<div class="mx-auto">
<div class="card-group">

<div class="card" style="width: 18rem;">
  <div class="card-body">
    <h5 class="card-title">Halaman Absensi</h5>
    <p class="card-text">Halaman ini digunakan oleh siswa untuk melakukan absen dan dikirim kepada guru</p>
    <a href="absen.php" class="btn btn-success">Masuk ke absen</a>
  </div>
</div>

<div class="card" style="width: 18rem;">
  <div class="card-body">
    <h5 class="card-title">Halaman Tugas</h5>
    <p class="card-text">Halaman ini digunakan oleh siswa untuk mengerjakan tugas yang diberikan oleh guru</p>
    <a href="macamtugas.html" class="btn btn-success">Kerjakan tugas</a>
  </div>
</div>

</div>
</div>
</div>

</body>


<?php
include("footer.php");
?>