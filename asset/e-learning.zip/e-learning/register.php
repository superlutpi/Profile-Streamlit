<?php
$host       = "localhost";
$user       = "root";
$pass       = "";
$db         = "lutpi";

$koneksi    = mysqli_connect($host, $user, $pass, $db);
if (!$koneksi) { //cek koneksi
    die("Tidak bisa terkoneksi ke database");
}
$username       = "";
$password       = "";
$namalengkap    = "";
$nohp           = "";
$kelamin        = "";
$status         = "";
$sukses         = "";
$error          = "";

if (isset($_POST['simpan'])) { //untuk create
    $username        = $_POST['username'];
    $password        = $_POST['password'];
    $namalengkap     = $_POST['namalengkap'];
    $nohp            = $_POST['nohp'];
    $kelamin         = $_POST['kelamin'];
    $status          = $_POST['status'];

    if ($username && $password && $namalengkap && $nohp && $kelamin && $status){
        $sql1   = "insert into akun(username,password,namalengkap,nohp,kelamin,status) values ('$username','$password','$namalengkap','$nohp','$kelamin','$status')";
        $q1     = mysqli_query($koneksi, $sql1);
        if ($q1) {
            $sukses     = "Berhasil membuat akun, silahkan menunggu konfirmasi dari admin untuk mendapatkan akses";
        } else {
            $error      = "Gagal membuat akun";
        }
    }
    else {
        $error = "Silakan masukkan semua data";
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <style>
        body {
            background-color: beige;
        }
        .mx-auto {
            width: 60%;
        }

        .card {
            margin-top: 10px;
        }

        .hai{
            margin-top: 20px;
        }

        .helo{
            margin-right: 10px;
        }
    </style>
</head>

<body>
    <br>
    <div class="mx-auto">
        <!-- untuk memasukkan data -->
        <div class="card">
            <div class="card-header">
                Buat Akun
            </div>
            <div class="card-body">
                <?php
                if ($error) {
                ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo $error ?>
                    </div>
                <?php
                    header("refresh:3;url=register.php");//3 : detik
                }
                ?>
                <?php
                if ($sukses) {
                ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo $sukses ?>
                    </div>
                <?php
                    header("refresh:5;url=register.php");
                }
                ?>
                <form action="" method="POST">
                    <div class="mb-3 row">
                        <label for="username" class="col-sm-2 col-form-label">Username</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="username" name="username" value="<?php echo $username ?>">
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="password" class="col-sm-2 col-form-label">Password</label>
                        <div class="col-sm-10">
                            <input type="password" class="form-control" id="password" name="password" value="<?php echo $password ?>">
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="namalengkap" class="col-sm-2 col-form-label">Nama Lengkap</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="namalengkap" name="namalengkap" value="<?php echo $namalengkap ?>">
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="nohp" class="col-sm-2 col-form-label">No HP</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="nohp" name="nohp" value="<?php echo $nohp ?>">
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="kelamin" class="col-sm-2 col-form-label">Kelamin</label>
                        <div class="col-sm-10">
                            <select class="form-control" name="kelamin" id="kelamin">
                                <option value="">- Pilih Kelamin -</option>
                                <option value="Laki-Laki" <?php if ($kelamin == "Laki-Laki") echo "selected" ?>>Laki-Laki</option>
                                <option value="Perempuan" <?php if ($kelamin == "Perempuan") echo "selected" ?>>Perempuan</option>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="status" class="col-sm-2 col-form-label">Status</label>
                        <div class="col-sm-10">
                            <select class="form-control" name="status" id="status">
                                <option value="">- Status -</option>
                                <option value="Guru" <?php if ($status == "guru") echo "selected" ?>>Guru</option>
                                <option value="Siswa" <?php if ($status == "siswa") echo "selected" ?>>Siswa</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-12">
                        <input type="submit" name="simpan" value="Simpan Data" class="btn btn-primary" onclick="return confirm('Pastikan data yang diisi benar')"/>
                        <a href="login.php"><input type="button" name="kembali" value="Kembali" class="btn btn-warning"></a>
                    </div>
                </form>
            </div>
        </div>
    </div>

</body>
</html>