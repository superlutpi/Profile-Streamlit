<?php
$host       = "localhost";
$user       = "root";
$pass       = "";
$db         = "lutpi";

$koneksi    = mysqli_connect($host, $user, $pass, $db);
if (!$koneksi) { //cek koneksi
    die("Tidak bisa terkoneksi ke database");
}
$pertanyaanessay    = "";
$jawabessay         = "";
$nomoressay         = "";
$namapenjawabessay  = "";
$sukses             = "";
$error              = "";

if (isset($_POST['kirimjawabanessay'])) { //untuk create
    $jawabessay          = $_POST['jawabessay'];
    $namapenjawabessay   = $_POST['namapenjawabessay'];

    if ($jawabessay && $namapenjawabessay){
        $sql8   = "insert into jawabanessay(jawabessay,namapenjawabessay) values ('$jawabessay', '$namapenjawabessay')";
        $q8     = mysqli_query($koneksi, $sql8);
        if ($q8) {
            $sukses     = "Jawaban terkirim";
        } else {
            $error      = "Gagal mengirim jawaban";
        }
    }
    else {
        $error = "Silakan masukkan semua data";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tugas Latihan Essay</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <style>
        body {
            background-color: #577d86;
        }
        .mx-auto {
            width: 90%;
        }

        .card {
            margin-top: 10px;
        }

        .hai{
            margin-top: 20px;
        }

        .helo{
            margin-right: 10px;
        }
    </style>
</head>

<body>
<br>
<div class="mx-auto">
<div class="card">
            <div class="card-header text-white bg-secondary">
                Latihan Essay
            </div>
            <div class="card-body">
                <table class="table">
                    <thead>
                    </thead>

                    <tbody>
                        <?php
                        $sql4   = "select * from soalessay order by nomoressay desc";
                        $q4     = mysqli_query($koneksi, $sql4);
                        while ($r4 = mysqli_fetch_array($q4)) {
                            $nomoressay          = $r4['nomoressay'];
                            $pertanyaanessay     = $r4['pertanyaanessay'];

                        ?>

                        <?php
                            if ($error) {
                        ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo $error ?>
                        </div>
                        <?php
                            header("refresh:1;url=tugasessay.php");//3 : detik
                        }
                        ?>

                        <?php
                            if ($sukses) {
                        ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo $sukses ?>
                        </div>
                        <?php
                            header("refresh:1;url=tugasessay.php");
                        }
                        ?>

                            <form action="" method="POST">
                            <!--1-->
                            <div class="mb-3 row">
                                <b><label for="namapenjawabessay" class="col-sm-2 col-form-label">Nama Lengkap :</label></b>
                                <div class="col-sm-5">
                                <input type="text" class="form-control" name="namapenjawabessay" id="namapenjawabessay">
                            </div>
                            </div>
                            <!--2-->
                            <li><?php echo $pertanyaanessay ?></li>
                            <input type="text" class="form-control" name="jawabessay" id="jawabessay" value="<?php echo $jawabessay ?>">
                            <br>
                            <!--3-->
                            <div class="col-12">
                            <input type="submit" name="kirimjawabanessay" value="Kirim Jawaban" class="btn btn-primary" onclick="return confirm('Pastikan jawaban sudah benar')"/>
                            </div>
                            <hr>
                            </form>
                        <?php
                        }
                        ?>
                    <br>
                    </tbody>
                    <div class="col-12">
                        <a href="siswa.php"><input type="button" name="kembali" value="Kembali" class="btn btn-warning"></a>
                    </div>
                </table>
            </div>
        </div>
</div>
</body>