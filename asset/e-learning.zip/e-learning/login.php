<?php
session_start();
if (isset($_SESSION['akun_username'])) {
    header("location:utama.php");
}

include("connection.php");
$username = "";
$password = "";
$nama     = "";
$user_id  = "";
$err      = "";

if (isset($_POST['login'])) {
    $username   = $_POST['username'];
    $password   = $_POST['password'];
    if ($username == '' or $password == '') {
        $err .= "<li>Silakan masukkan username dan password</li>";
    }
    if (empty($err)) {
        $sql1 = "SELECT * FROM akun WHERE username = '$username'";
        $q1 = mysqli_query($koneksi, $sql1);
        $r1 = mysqli_fetch_array($q1);
    
        if($r1){
            if ($r1['password'] != ($password)) {
                $err .= "<li>Username atau Password salah</li>";
            }else{
                $nama = $r1['namalengkap'];
                $user_id = $r1['login_id'];
            }
        }else{
            $err .= "<li>Username atau Password salah</li>";
        }
    }
    if (empty($err)) {
        $login_id = $r1['login_id'];
        $sql1 = "select * from akun_akses where login_id = '$login_id'";
        $sql11 = "select * from akun where login_id = '$login_id'";
        $q1 = mysqli_query($koneksi, $sql1);
        while ($r1 = mysqli_fetch_array($q1)) {
            $akses[] = $r1['id_akses']; //akses akun dari tabel akun_akses
            $akses[] = $r1['login_id']; //login id dari tabel akun
        }
        if (empty($akses)) {
            $err .= "<li>Kamu tidak punya akses</li>";
        }
    }
    if (empty($err)) {
        $_SESSION['akun_username'] = $username;
        $_SESSION['user_id'] = $user_id;
        $_SESSION['nama'] = $nama;
        $_SESSION['akun_akses'] = $akses;
        header("location:utama.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <link href="style.css" rel="stylesheet">
    <style>
        body{
            background-color: beige;
        }
    </style>
</head>

<body>
<br><br>
<center>
<div class="card" style="width: fit-content;">
  <div class="card-body">
    <h5 class="card-title">Selamat Datang di Halaman Login</h5>
    <br>
    <?php
        if ($err) {
            echo "<ul>$err</ul>";
        }
        ?>

<!--Inputan-->
<form action="" method="post">
    <div class="input-group flex-nowrap">
        <span class="input-group-text" id="addon-wrapping"><img src="img/username.jpg" width="20"></span>
        <input type="text" class="form-control" placeholder="Username" aria-label="Username" aria-describedby="addon-wrapping" value="<?php echo $username ?>" name="username">
    </div>
    <br>
    <div class="input-group flex-nowrap">
        <span class="input-group-text" id="addon-wrapping"><img src="img/password.jpg" width="20"></span>
        <input type="password" class="form-control" placeholder="Password" aria-label="Password" aria-describedby="addon-wrapping" name="password">
    </div>
    <br>
    <div>
        <input type="submit" name="login" value="Login" class="btn btn-success"/>
    </div>
    <br>
    <div class="card" style="width: 18rem;">
        <img src="img/messi.jpg" class="card-img-top">
        <div class="card-body">
        <p class="card-text">Apabila belum punya akun silahkan buat terlebih dahulu.</p>
        <a href="register.php">Buat Akun</a>
        </div>
    </div>
  </div>
</div>
</div>
</center>

</form>
</body>
</html>