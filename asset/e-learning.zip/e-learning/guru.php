<?php
include("connection.php");
include("header.php");

if (!in_array("guru", $_SESSION['akun_akses'])) {
    echo "Kamu tidak punya akses";
    include("footer.php");
    exit();
}
?>

<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Guru</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <style>
        body {
            background-color: beige;
        }
        .mx-auto {
            width: 60%;
        }

        .card {
            margin-top: 10px;
        }

        .hai{
            margin-top: 20px;
        }

        .helo{
            margin-right: 10px;
        }
    </style>
</head>

<body background="img/work.jpg">
<center><h1><b>Halaman Guru</b></h1></center>
<center><p>Selamat datang di halaman guru</p></center>
<br>

<div>
<div class="mx-auto">
<div class="card-group">

<div class="card" style="width: 18rem;">
  <div class="card-body">
    <h5 class="card-title">Rekap tugas</h5>
    <p class="card-text">Halaman ini digunakan untuk melihat rekap tugas yang telah dikerjakan oleh siswa</p>
    <a href="rekaptugas.html" class="btn btn-success">Lihat rekap tugas</a>
  </div>
</div>

<div class="card" style="width: 18rem;">
  <div class="card-body">
    <h5 class="card-title">Rekap absensi kehadiran</h5>
    <p class="card-text">Halaman ini digunakan untuk melihat rekap absensi kehadiran setiap pembelajaran siswa</p>
    <a href="rekapabsen.php" class="btn btn-success">Lihat absensi</a>
  </div>
</div>

<div class="card" style="width: 18rem;">
  <div class="card-body">
    <h5 class="card-title">Buat latihan soal</h5>
    <p class="card-text">Halaman ini digunakan untuk memberikan latihan latihan soal kepada siswa agar dikerjakan</p>
    <a href="macamsoal.html" class="btn btn-success">Buat soal</a>
  </div>
</div>

</div>
</div>
</div>

</body>

<?php
include("footer.php");
?>