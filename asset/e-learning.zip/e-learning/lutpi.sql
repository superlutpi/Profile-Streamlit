-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 30, 2023 at 08:36 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lutpi`
--

-- --------------------------------------------------------

--
-- Table structure for table `absen`
--

CREATE TABLE `absen` (
  `namaabsen` varchar(255) NOT NULL,
  `hari` varchar(25) NOT NULL,
  `tanggal` varchar(25) NOT NULL,
  `nomorhp` varchar(25) NOT NULL,
  `pembelajaran` varchar(25) NOT NULL,
  `absen_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `absen`
--

INSERT INTO `absen` (`namaabsen`, `hari`, `tanggal`, `nomorhp`, `pembelajaran`, `absen_id`) VALUES
('Lutpi', 'Rabu', '17 Mei 2002', '081287986865', 'tatapmuka', 3),
('Ziddan', 'Senin', '5 Juni 2023', '081288882222', 'tugas', 4),
('Lutpi Ganteng', 'Sabtu', '10 Juni 2023', '0899', 'tatapmuka', 5);

-- --------------------------------------------------------

--
-- Table structure for table `akun`
--

CREATE TABLE `akun` (
  `login_id` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(255) NOT NULL,
  `namalengkap` varchar(255) NOT NULL,
  `nohp` varchar(15) NOT NULL,
  `kelamin` varchar(25) NOT NULL,
  `status` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `akun`
--

INSERT INTO `akun` (`login_id`, `username`, `password`, `namalengkap`, `nohp`, `kelamin`, `status`) VALUES
(1, 'upi', 'upi', 'Upi Gans', '081287986865', 'Laki-Laki', 'Super Admin'),
(2, 'guru', 'guru', 'Pak Lutpi', '02181819090', 'Laki-Laki', 'Guru'),
(3, 'lutpi', 'lutpi', 'Lutpi Ganteng', '08523234040', 'Laki-Laki', 'Siswa'),
(14, 'superlutpi', 'superlutpi', 'Super Lutpi', '0000000000', 'Laki-Laki', 'Siswa');

-- --------------------------------------------------------

--
-- Table structure for table `akun_akses`
--

CREATE TABLE `akun_akses` (
  `login_id` int(11) NOT NULL,
  `id_akses` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `akun_akses`
--

INSERT INTO `akun_akses` (`login_id`, `id_akses`) VALUES
(1, 'admin'),
(1, 'guru'),
(1, 'siswa'),
(2, 'guru'),
(3, 'siswa'),
(14, 'siswa');

-- --------------------------------------------------------

--
-- Table structure for table `jawabanessay`
--

CREATE TABLE `jawabanessay` (
  `idessay` int(11) NOT NULL,
  `akun_id` int(11) NOT NULL,
  `jawabessay` varchar(255) NOT NULL,
  `soalessay_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jawabanessay`
--

INSERT INTO `jawabanessay` (`idessay`, `akun_id`, `jawabessay`, `soalessay_id`) VALUES
(5, 1, 'eaklo', 1);

-- --------------------------------------------------------

--
-- Table structure for table `jawabanpg`
--

CREATE TABLE `jawabanpg` (
  `id` int(11) NOT NULL,
  `akun_id` int(100) NOT NULL,
  `jawabpg` varchar(255) NOT NULL,
  `soal_id` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jawabanpg`
--

INSERT INTO `jawabanpg` (`id`, `akun_id`, `jawabpg`, `soal_id`) VALUES
(11, 1, 'D', 4),
(16, 3, 'C', 4),
(17, 1, 'B', 4);

-- --------------------------------------------------------

--
-- Table structure for table `master_akses`
--

CREATE TABLE `master_akses` (
  `id_akses` varchar(10) NOT NULL,
  `nama` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `master_akses`
--

INSERT INTO `master_akses` (`id_akses`, `nama`) VALUES
('admin', 'Admin'),
('guru', 'Guru'),
('siswa', 'Siswa');

-- --------------------------------------------------------

--
-- Table structure for table `soal`
--

CREATE TABLE `soal` (
  `nomor` int(11) NOT NULL,
  `pertanyaan` varchar(500) NOT NULL,
  `jawaban_a` varchar(500) NOT NULL,
  `jawaban_b` varchar(500) NOT NULL,
  `jawaban_c` varchar(500) NOT NULL,
  `jawaban_d` varchar(500) NOT NULL,
  `jawabanbenar` enum('a','b','c','d') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `soal`
--

INSERT INTO `soal` (`nomor`, `pertanyaan`, `jawaban_a`, `jawaban_b`, `jawaban_c`, `jawaban_d`, `jawabanbenar`) VALUES
(4, 'Siapa saya?', 'Upi', 'Upi keren', 'Upi ganteng', 'Upi aja', 'a');

-- --------------------------------------------------------

--
-- Table structure for table `soalessay`
--

CREATE TABLE `soalessay` (
  `nomoressay` int(11) NOT NULL,
  `pertanyaanessay` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `soalessay`
--

INSERT INTO `soalessay` (`nomoressay`, `pertanyaanessay`) VALUES
(1, 'Sebutkan manusia paling ganteng menurut anda dan jelaskan alasannya!'),
(4, 'Siapa manusia paling keren?');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `absen`
--
ALTER TABLE `absen`
  ADD PRIMARY KEY (`absen_id`);

--
-- Indexes for table `akun`
--
ALTER TABLE `akun`
  ADD PRIMARY KEY (`login_id`);

--
-- Indexes for table `akun_akses`
--
ALTER TABLE `akun_akses`
  ADD KEY `id_akses` (`id_akses`),
  ADD KEY `login_id` (`login_id`);

--
-- Indexes for table `jawabanessay`
--
ALTER TABLE `jawabanessay`
  ADD PRIMARY KEY (`idessay`);

--
-- Indexes for table `jawabanpg`
--
ALTER TABLE `jawabanpg`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_akses`
--
ALTER TABLE `master_akses`
  ADD PRIMARY KEY (`id_akses`);

--
-- Indexes for table `soal`
--
ALTER TABLE `soal`
  ADD PRIMARY KEY (`nomor`);

--
-- Indexes for table `soalessay`
--
ALTER TABLE `soalessay`
  ADD PRIMARY KEY (`nomoressay`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `absen`
--
ALTER TABLE `absen`
  MODIFY `absen_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `akun`
--
ALTER TABLE `akun`
  MODIFY `login_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `jawabanessay`
--
ALTER TABLE `jawabanessay`
  MODIFY `idessay` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `jawabanpg`
--
ALTER TABLE `jawabanpg`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `soal`
--
ALTER TABLE `soal`
  MODIFY `nomor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `soalessay`
--
ALTER TABLE `soalessay`
  MODIFY `nomoressay` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `akun_akses`
--
ALTER TABLE `akun_akses`
  ADD CONSTRAINT `akun_akses_ibfk_1` FOREIGN KEY (`id_akses`) REFERENCES `master_akses` (`id_akses`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
