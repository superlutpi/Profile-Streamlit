<?php
$host       = "localhost";
$user       = "root";
$pass       = "";
$db         = "lutpi";

$koneksi    = mysqli_connect($host, $user, $pass, $db);
if (!$koneksi) { //cek koneksi
    die("Tidak bisa terkoneksi ke database");
}
$pertanyaanessay    = "";
$nomoressay         = "";
$sukses         = "";
$error          = "";

if (isset($_GET['op'])) {
    $op = $_GET['op'];
} else {
    $op = "";
}
if($op == 'delete'){
    $nomoressay = $_GET['nomoressay'];
    $sql3       = "delete from soalessay where nomoressay = '$nomoressay'";
    $q3         = mysqli_query($koneksi,$sql3);
    if($q3){
        $sukses = "Berhasil hapus data";
    }else{
        $error  = "Gagal melakukan delete data";
    }
}
if ($op == 'edit') {
    $nomoressay         = $_GET['nomoressay'];
    $sql3               = "select * from soalessay where nomoressay = '$nomoressay'";
    $q3                 = mysqli_query($koneksi, $sql3);
    $r3                 = mysqli_fetch_array($q3);
    $pertanyaanessay    = $r3['pertanyaanessay'];

    if ($nomoressay == '') {
        $error = "Data tidak ditemukan";
    }
}
if (isset($_POST['kirimessay'])) { //untuk create
    $pertanyaanessay       = $_POST['pertanyaanessay'];

if ($pertanyaanessay) {
    if ($op == 'edit') { //untuk update
        $sql3       = "update soalessay set pertanyaanessay = '$pertanyaanessay' where nomoressay = '$nomoressay'";
        $q3         = mysqli_query($koneksi, $sql3);
        if ($q3) {
            $sukses = "Data berhasil diupdate";
        } else {
            $error  = "Data gagal diupdate";
        }
    } 
    else { //untuk edit
        $sql3   = "insert into soalessay(nomoressay,pertanyaanessay) values ('$nomoressay','$pertanyaanessay')";
        $q3     = mysqli_query($koneksi, $sql3);
        if ($q3) {
            $sukses     = "Berhasil memasukkan data baru";
        } else {
            $error      = "Gagal memasukkan data";
        }
    }
} 
else {
    $error = "Silakan masukkan semua data";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pembuatan Soal Essay</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <style>
        body {
            background-color: beige;
        }
        .mx-auto {
            width: 90%;
        }

        .card {
            margin-top: 10px;
        }

        .hai{
            margin-top: 20px;
        }

        .helo{
            margin-right: 10px;
        }
    </style>
</head>

<body>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pembuatan Soal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <style>
        body {
            background-color: #5C8984;
        }
        .mx-auto {
            width: 90%;
        }

        .card {
            margin-top: 10px;
        }

        .hai{
            margin-top: 20px;
        }

        .helo{
            margin-right: 10px;
        }
    </style>
</head>

<body>
<br>
<div class="mx-auto">
        <!-- untuk memasukkan data -->
        <div class="card">
            <div class="card-header">
                Buat soal essay
            </div>
            <div class="card-body">
                <?php
                if ($error) {
                ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo $error ?>
                    </div>
                <?php
                    header("refresh:3;url=soalessay.php");//3 : detik
                }
                ?>
                <?php
                if ($sukses) {
                ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo $sukses ?>
                    </div>
                <?php
                    header("refresh:5;url=soalessay.php");
                }
                ?>
                <form action="" method="POST">
                    <div class="mb-3 row">
                        <label for="pertanyaanessay" class="col-sm-2 col-form-label">Pertanyaan</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="pertanyaanessay" name="pertanyaanessay" value="<?php echo $pertanyaanessay ?>">
                        </div>
                    </div>

                    <div class="col-12">
                        <input type="submit" name="kirimessay" value="Simpan Data" class="btn btn-primary" />
                    </div>
                </form>
            </div>
        </div>

        <!-- untuk mengeluarkan data -->
        <div class="card">
            <div class="card-header text-white bg-secondary">
                Hasil soal yang dibuat
            </div>
            <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">ID Soal</th>
                            <th scope="col">Pertanyaan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $sql4   = "select * from soalessay order by nomoressay desc";
                        $q4     = mysqli_query($koneksi, $sql4);
                        while ($r4 = mysqli_fetch_array($q4)) {
                            $nomoressay          = $r4['nomoressay'];
                            $pertanyaanessay     = $r4['pertanyaanessay'];
                        ?>
                            <tr>
                                <th scope="row"><?php echo $nomoressay ?></th>
                                <td scope="row"><?php echo $pertanyaanessay ?></td>
                                <td scope="row">
                                    <a href="soalessay.php?op=edit&nomoressay=<?php echo $nomoressay ?>"><button type="button" class="btn btn-warning">Edit</button></a>
                                    <a href="soalessay.php?op=delete&nomoressay=<?php echo $nomoressay?>" onclick="return confirm('Yakin mau delete data?')"><button type="button" class="btn btn-danger">Delete</button></a>            
                                </td>
                            </tr>
                        <?php
                        }
                        ?>
                    
                    </tbody>
                    
                </table>
                <div class="col-12">
                        <a href="guru.php"><input type="button" name="kembali" value="Kembali" class="btn btn-warning"></a>
                    </div>
            </div>
        </div>
    </div>
</body>


</html>

<br><br>
<?php
include("footer.php");
?>