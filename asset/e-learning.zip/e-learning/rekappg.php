<?php
$host       = "localhost";
$user       = "root";
$pass       = "";
$db         = "lutpi";

$koneksi    = mysqli_connect($host, $user, $pass, $db);
if (!$koneksi) { //cek koneksi
    die("Tidak bisa terkoneksi ke database");
}
$namapenjawab   = "";
$nomor          = "";
$pertanyaan     = "";
$jawabpg        = "";

$query = 'SELECT akun.namalengkap, soal.pertanyaan, jawabanpg.jawabpg FROM jawabanpg JOIN akun ON akun.login_id = jawabanpg.akun_id 
JOIN soal ON soal.nomor = jawabanpg.soal_id ';
$exe = mysqli_query($koneksi, $query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tugas Latihan Essay</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <style>
        body {
            background-color: #577d86;
        }
        .mx-auto {
            width: 90%;
        }

        .card {
            margin-top: 10px;
        }

        .hai{
            margin-top: 20px;
        }

        .helo{
            margin-right: 10px;
        }
    </style>
</head>

<body>
<br>
<div class="mx-auto">
<div class="card">
            <div class="card-header text-white bg-secondary">
                Rekap Latihan Pilihan Ganda
            </div>
            <div class="card-body">
                <table class="table">
                    <thead>
                    <tr>
                        <th scope="col">Pertanyaan</th>
                        <th scope="col">Jawaban</th>
                        <th scope="col">Nama Lengkap</th>
                    </tr>
                    </thead>

                    <tbody>
                        <?php while($res = mysqli_fetch_array($exe)):?>
                            <tr>
                                <td><?= $res['pertanyaan'] ?></td>
                                <td><?= $res['jawabpg'] ?></td>
                                <td><?= $res['namalengkap'] ?></td>
                            </tr>
                        <?php endwhile ?>
                    </tbody>
                    <div class="col-12">
                        <a href="guru.php"><input type="button" name="kembali" value="Kembali" class="btn btn-warning"></a>
                    </div>
                </table>
            </div>
        </div>
</div>
</body>