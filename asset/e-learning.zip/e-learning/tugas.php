<?php
session_start();

$host       = "localhost";
$user       = "root";
$pass       = "";
$db         = "lutpi";

$koneksi    = mysqli_connect($host, $user, $pass, $db);
if (!$koneksi) { //cek koneksi
    die("Tidak bisa terkoneksi ke database");
}

$sql2   = "SELECT * FROM soal";
$q2     = mysqli_query($koneksi, $sql2);
$length = mysqli_num_rows($q2);

$namapenjawab   = "";
$sukses         = "";
$error          = "";
$no             = 1;

if (isset($_POST['kirimjawabanpg'])) { //untuk create
    $namapenjawab   = $_POST['namapenjawab'];

    for ($i=1; $i <=$length ; $i++) { 
        $jawabpg = $_POST['jawabpg'.$i];
        $soal_id = $_POST['soal_id'.$i];

        if ($jawabpg){
            $sql7   = "INSERT INTO jawabanpg(akun_id,jawabpg,soal_id) values ('$namapenjawab', '$jawabpg', '$soal_id')";
            $q7     = mysqli_query($koneksi, $sql7);
            if ($q7) {
                $sukses     = "Jawaban terkirim";
            } else {
                $error      = "Gagal mengirim jawaban";
            }
        }
        else {
            $error = "Silakan masukkan semua data";
        }
    }

}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tugas Latihan Pilihan Ganda</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <style>
        body {
            background-color: #577d86;
        }
        .mx-auto {
            width: 90%;
        }

        .card {
            margin-top: 10px;
        }

        .hai{
            margin-top: 20px;
        }

        .helo{
            margin-right: 10px;
        }
    </style>
</head>

<body>
<br>
<div class="mx-auto">
<div class="card">
            <div class="card-header text-white bg-secondary">
                Latihan pilihan ganda
            </div>
            <div class="card-body">
                <table class="table">
                    <thead>
                    </thead>

                    <tbody>
                    <?php
                        if ($error) : ?>
                            <div class="alert alert-danger" role="alert">
                                <?= $error ?>
                            </div>
                        <?php 
                        header("refresh:1;url=tugas.php");//3 : detik
                        endif
                        ?>
                        <?php if ($sukses) : ?>
                            <div class="alert alert-success" role="alert">
                            <?= $sukses ?>
                        </div>
                        <?php 
                        header("refresh:1;url=tugas.php");//3 : detik
                        endif
                        ?>
                        
                         <form action="" method="POST">
                         <!--1-->
                         <div class="mb-3 row col-sm-12">
                             <b><label for="namapenjawab" class="col-sm-2 col-form-label">Nama Lengkap : <?= $_SESSION['nama'] ?></label></b>
                             <div class="col-sm-5">
                                <input type="hidden" class="form-control" name="namapenjawab" id="namapenjawab" value="<?= $_SESSION['user_id'] ?>">
                             </div>
                         </div>
                         <!--2-->
                            <?php while($result = mysqli_fetch_array($q2)) : ?>
                                <div class="mb-1">
                                    <input type="hidden" name="soal_id<?=$no?>" value="<?=$result['nomor']?>">
                                    <h6><?=$no?> ) <?= $result['pertanyaan'] ?></h6>
                                    <li type="none">A.<?= $result['jawaban_a'] ?>
                                    <li type="none">B.<?= $result['jawaban_b'] ?>
                                    <li type="none">C.<?= $result['jawaban_c'] ?>
                                    <li type="none">D.<?= $result['jawaban_d'] ?>
                                </div>
                         <!--3-->
                                <label for="jawabpg"></label>
                                <div class="mb-4">
                                    <select class="col" name="jawabpg<?=$no?>" id="jawabpg" width="" required>
                                        <option value="">- Jawab -</option>
                                        <option value="A" >A</option>
                                        <option value="B" >B</option>
                                        <option value="C" >C</option>
                                        <option value="D" >D</option>
                                    </select><br>
                                </div>
                            <?php $no++; endwhile ?>
                         <!--4-->
                             <br>
                             <div class="col-12">
                             <input type="submit" name="kirimjawabanpg" value="Kirim Jawaban" class="btn btn-primary" onclick="return confirm('Pastikan jawaban sudah benar')"/>
                             </div>
                             <hr>
                         </form>
                    </tbody>
                    <div class="col-12">
                        <a href="siswa.php"><input type="button" name="kembali" value="Kembali" class="btn btn-warning"></a>
                    </div>
                </table>
            </div>
        </div>
</div>
</body>