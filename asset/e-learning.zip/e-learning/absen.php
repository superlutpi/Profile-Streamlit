<?php
session_start();

$host       = "localhost";
$user       = "root";
$pass       = "";
$db         = "lutpi";

$koneksi    = mysqli_connect($host, $user, $pass, $db);
if (!$koneksi) { //cek koneksi
    die("Tidak bisa terkoneksi ke database");
}

$namaabsen      = "";
$hari           = "";
$tanggal        = "";
$nomorhp        = "";
$pembelajaran   = "";
$sukses         = "";
$error          = "";

if (isset($_POST['kirimabsen'])) { //untuk kirim absen
    $namaabsen      = $_POST['namaabsen'];
    $hari           = $_POST['hari'];
    $tanggal        = $_POST['tanggal'];
    $nomorhp        = $_POST['nomorhp'];
    $pembelajaran   = $_POST['pembelajaran'];

    if ($namaabsen && $hari && $tanggal && $nomorhp && $pembelajaran){
        $sql5   = "insert into absen(namaabsen,hari,tanggal,nomorhp,pembelajaran) values ('$namaabsen','$hari','$tanggal','$nomorhp','$pembelajaran')";
        $q5     = mysqli_query($koneksi, $sql5);
        if ($q5) {
            $sukses     = "Berhasil melakukan absen";
        } else {
            $error      = "Gagal melakukan absen";
        }
    }
    else {
        $error = "Silakan masukkan semua data";
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Absensi Kehadiran</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <style>
        body {
            background-color: beige;
        }
        .mx-auto {
            width: 70%;
        }

        .card {
            margin-top: 10px;
        }

        .hai{
            margin-top: 20px;
        }

        .helo{
            margin-right: 10px;
        }
    </style>
</head>

<body background="img/absen.png">
    <br><br><br><br>
    <div class="mx-auto">
        <!-- untuk memasukkan data -->
        <div class="card">
            <div class="card-header">
                Absensi Kehadiran
            </div>
            <div class="card-body">
                <?php
                if ($error) {
                ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo $error ?>
                    </div>
                <?php
                    header("refresh:3;url=absen.php");//3 : detik
                }
                ?>
                <?php
                if ($sukses) {
                ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo $sukses ?>
                    </div>
                <?php
                    header("refresh:5;url=absen.php");
                }
                ?>
                <form action="" method="POST">
                    <div class="mb-3 row">
                        <h3><label for="namaabsen" class="col-sm-5 col-form-label">Halo,  <b><?php echo $_SESSION['nama'] ?></b></label></h3>
                        <div class="col-sm-10">
                            <input type="hidden" class="form-control" id="namaabsen" name="namaabsen" value="<?php echo $_SESSION['nama'] ?>">
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="hari" class="col-sm-2 col-form-label">Hari</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="hari" name="hari" value="<?php echo $hari ?>">
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="tanggal" class="col-sm-2 col-form-label">Tanggal</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="tanggal" name="tanggal" value="<?php echo $tanggal ?>">
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="nomorhp" class="col-sm-2 col-form-label">Nomor HP</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="nomorhp" name="nomorhp" value="<?php echo $nomorhp ?>">
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="pembelajaran" class="col-sm-2 col-form-label">Pembelajaran</label>
                        <div class="col-sm-10">
                            <select class="form-control" name="pembelajaran" id="pembelajaran">
                                <option value="">- Pilih Pembelajaran -</option>
                                <option value="tatapmuka" <?php if ($pembelajaran == "tatapmuka") echo "selected" ?>>Tatap Muka</option>
                                <option value="tugas" <?php if ($pembelajaran == "tugas") echo "selected" ?>>Tugas</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-12">
                        <input type="submit" name="kirimabsen" value="Simpan Data" class="btn btn-primary" onclick="return confirm('Pastikan data yang diisi benar')"/>
                        <a href="siswa.php"><input type="button" name="kembali" value="Kembali" class="btn btn-warning"></a>
                    </div>
                </form>
            </div>
        </div>
    </div>

</body>
</html>