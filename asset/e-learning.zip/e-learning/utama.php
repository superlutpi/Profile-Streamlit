<?php
include("header.php");
?>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Utama</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <style>
        .mx-auto {
            width: 60%;
            height: auto;
        }
        .ea {
          width: 55%;
        }
        .hai{
            margin-top: 20px;
        }

        .helo{
            margin-right: 10px;
        }
    </style>
</head>

<body background="img/bglagi2.jpg">
<center><h1><b>Halaman Utama</b></h1></center>
<br>

<center>
<div class="ea">
<b>
Website ini merupakan media pembelajaran yang dapat diakses oleh
guru maupun siswa. Website ini bertujuan untuk mempermudah komunikasi
antara guru maupun siswa dalam kegiatan belajar mengajar
</b>
</div>
</center>

<br>
<div class="mx-auto">
<div class="card-group">
  <div class="card">
    <center><img src="img/easy-to-use.png" class="card-img-top" alt="..." style="max-width: 10rem; margin-top: 5%;"></center>
    <div class="card-body">
      <br>
      <center><h5 class="card-title">Mudah Digunakan</h5>
      <p class="card-text">Website ini dirancang se-simple mungkin dengan upaya semua user dapat memahami website dengan mudah.</p></center>
    </div>
  </div>
  <div class="card">
    <center><img src="img/discussion.png" class="card-img-top" alt="..." style="max-width: 10rem; margin-top: 5%;"></center>
    <div class="card-body">
      <br>
      <center><h5 class="card-title">Solusi yang tepat</h5>
      <p class="card-text">Dalam pembuatan soal latihan maupun pengerjaan soal latihan, website ini merupakan solusi yang sangat tepat.</p></center>
    </div>
  </div>
  <div class="card">
    <center><img src="img/salary.png" class="card-img-top" alt="..." style="max-width: 10rem; margin-top: 5%;"></center>
    <div class="card-body">
      <br>
      <center><h5 class="card-title">Ekonomis</h5>
      <p class="card-text">Untuk mengakses website ini tidak dipungut biaya sepeserpun, jadi tidak ada alasan untuk tidak bisa mengakses website berikut.</p></center>
    </div>
  </div>
</div>
</div>

</body>
</html>

<?php
include("footer.php");
?>