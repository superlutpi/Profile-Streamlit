<?php
$host       = "localhost";
$user       = "root";
$pass       = "";
$db         = "lutpi";

$koneksi    = mysqli_connect($host, $user, $pass, $db);
if (!$koneksi) { //cek koneksi
    die("Tidak bisa terkoneksi ke database");
}
$namaabsen      = "";
$hari           = "";
$tanggal        = "";
$nomorhp        = "";
$pembelajaran   = "";
$sukses         = "";
$error          = "";
$absen_id       = "";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekap Absensi Kehadiran</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <style>
        body {
            background-color: #577d86;
        }
        .mx-auto {
            width: 80%;
        }

        .card {
            margin-top: 10px;
        }

        .hai{
            margin-top: 20px;
        }

        .helo{
            margin-right: 10px;
        }
    </style>
</head>

<body>
<br>
<div class="mx-auto">
<div class="card">
            <div class="card-header text-white bg-secondary">
                Rekap absensi kehadiran
            </div>
            <div class="card-body">
                <table class="table">
                    <tbody>
                        <?php
                        $sql6   = "select * from absen order by absen_id desc";
                        $q6     = mysqli_query($koneksi, $sql6);
                        while ($r6 = mysqli_fetch_array($q6)) {
                            $namaabsen    = $r6['namaabsen'];
                            $hari         = $r6['hari'];
                            $tanggal      = $r6['tanggal'];
                            $nomorhp      = $r6['nomorhp'];
                            $pembelajaran = $r6['pembelajaran'];

                        ?>
                        
                        <ul>
                            <li><b><?php echo $namaabsen ?></b></li>
                            <li type="none">Hari    : <?php echo $hari ?></li>
                            <li type="none">Tanggal : <?php echo $tanggal ?></li>
                            <li type="none">No HP   : <?php echo $nomorhp ?></li>
                            <li type="none">Pembelajaran : <?php echo $pembelajaran ?></li>
                        </ul>
                        <hr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
                <div class="col-12">
                    <a href="guru.php"><input type="button" name="kembali" value="Kembali" class="btn btn-warning"></a>
                </div>
            </div>
        </div>
</div>
</body>